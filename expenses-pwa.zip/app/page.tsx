"use client"

import * as React from "react"
import Image from "next/image"
import { format } from "date-fns"
import { enUS } from "date-fns/locale"
import { ExpenseCard } from "@/components/expense-card"
import { NavigationMenu, navItems } from "@/components/navigation-menu"
import { CalendarButton } from "@/components/calendar-button"

function requestNotificationPermission() {
  if ("Notification" in window) {
    Notification.requestPermission()
  }
}

function sendNotification(expense: { name: string; dueDate: Date }) {
  if ("Notification" in window && Notification.permission === "granted") {
    new Notification("Expense Due Soon", {
      body: `${expense.name} is due on ${format(expense.dueDate, "MMMM d", { locale: enUS })}`,
      icon: "/icon-192x192.png",
    })
  }
}

// Sample data for each menu item
const expensesData = [
  { id: 1, name: "Expense", dueDate: new Date(2025, 0, 26), amount: 100, paid: false },
  { id: 2, name: "Expense", dueDate: new Date(2025, 0, 27), amount: 100, paid: false },
  { id: 3, name: "Expense", dueDate: new Date(2025, 0, 28), amount: 100, paid: false },
  { id: 4, name: "Expense", dueDate: new Date(2025, 0, 30), amount: 100, paid: false },
  { id: 5, name: "Expense", dueDate: new Date(2025, 1, 2), amount: 100, paid: false },
  { id: 6, name: "Expense", dueDate: new Date(2025, 1, 4), amount: 100, paid: false },
  { id: 7, name: "Expense", dueDate: new Date(2025, 1, 7), amount: 100, paid: false },
  { id: 8, name: "Expense", dueDate: new Date(2025, 1, 9), amount: 100, paid: false },
  { id: 9, name: "Expense", dueDate: new Date(2025, 1, 11), amount: 100, paid: false },
  { id: 10, name: "Expense", dueDate: new Date(2025, 1, 14), amount: 100, paid: false },
  { id: 11, name: "Expense", dueDate: new Date(2025, 1, 17), amount: 100, paid: false },
  { id: 12, name: "Expense", dueDate: new Date(2025, 1, 19), amount: 100, paid: false },
  { id: 13, name: "Expense", dueDate: new Date(2025, 1, 21), amount: 100, paid: false },
  { id: 14, name: "Expense", dueDate: new Date(2025, 1, 24), amount: 100, paid: false },
  { id: 15, name: "Expense", dueDate: new Date(2025, 1, 27), amount: 100, paid: false },
  { id: 16, name: "Expense", dueDate: new Date(2025, 2, 1), amount: 100, paid: false },
  { id: 17, name: "Expense", dueDate: new Date(2025, 2, 4), amount: 100, paid: false },
  { id: 18, name: "Expense", dueDate: new Date(2025, 2, 9), amount: 100, paid: false },
  { id: 19, name: "Expense", dueDate: new Date(2025, 2, 14), amount: 100, paid: false },
  { id: 20, name: "Expense", dueDate: new Date(2025, 2, 19), amount: 100, paid: false },
]

const diegoExpenses = [
  { id: 1, name: "Expense", dueDate: new Date(2025, 0, 26), amount: 100, paid: false },
  { id: 2, name: "Expense", dueDate: new Date(2025, 0, 27), amount: 100, paid: false },
  { id: 3, name: "Expense", dueDate: new Date(2025, 0, 29), amount: 100, paid: false },
  { id: 4, name: "Expense", dueDate: new Date(2025, 0, 31), amount: 100, paid: false },
  { id: 5, name: "Expense", dueDate: new Date(2025, 1, 3), amount: 100, paid: false },
  { id: 6, name: "Expense", dueDate: new Date(2025, 1, 6), amount: 100, paid: false },
  { id: 7, name: "Expense", dueDate: new Date(2025, 1, 9), amount: 100, paid: false },
  { id: 8, name: "Expense", dueDate: new Date(2025, 1, 12), amount: 100, paid: false },
  { id: 9, name: "Expense", dueDate: new Date(2025, 1, 15), amount: 100, paid: false },
  { id: 10, name: "Expense", dueDate: new Date(2025, 1, 18), amount: 100, paid: false },
  { id: 11, name: "Expense", dueDate: new Date(2025, 1, 21), amount: 100, paid: false },
  { id: 12, name: "Expense", dueDate: new Date(2025, 1, 24), amount: 100, paid: false },
  { id: 13, name: "Expense", dueDate: new Date(2025, 1, 27), amount: 100, paid: false },
  { id: 14, name: "Expense", dueDate: new Date(2025, 2, 1), amount: 100, paid: false },
  { id: 15, name: "Expense", dueDate: new Date(2025, 2, 4), amount: 100, paid: false },
  { id: 16, name: "Expense", dueDate: new Date(2025, 2, 7), amount: 100, paid: false },
  { id: 17, name: "Expense", dueDate: new Date(2025, 2, 10), amount: 100, paid: false },
  { id: 18, name: "Expense", dueDate: new Date(2025, 2, 13), amount: 100, paid: false },
  { id: 19, name: "Expense", dueDate: new Date(2025, 2, 16), amount: 100, paid: false },
  { id: 20, name: "Expense", dueDate: new Date(2025, 2, 20), amount: 100, paid: false },
]

const caExpenses = [
  { id: 1, name: "Expense", dueDate: new Date(2025, 0, 26), amount: 100, paid: false },
  { id: 2, name: "Expense", dueDate: new Date(2025, 0, 28), amount: 100, paid: false },
  { id: 3, name: "Expense", dueDate: new Date(2025, 0, 30), amount: 100, paid: false },
  { id: 4, name: "Expense", dueDate: new Date(2025, 1, 1), amount: 100, paid: false },
  { id: 5, name: "Expense", dueDate: new Date(2025, 1, 3), amount: 100, paid: false },
  { id: 6, name: "Expense", dueDate: new Date(2025, 1, 6), amount: 100, paid: false },
  { id: 7, name: "Expense", dueDate: new Date(2025, 1, 9), amount: 100, paid: false },
  { id: 8, name: "Expense", dueDate: new Date(2025, 1, 12), amount: 100, paid: false },
  { id: 9, name: "Expense", dueDate: new Date(2025, 1, 15), amount: 100, paid: false },
  { id: 10, name: "Expense", dueDate: new Date(2025, 1, 18), amount: 100, paid: false },
  { id: 11, name: "Expense", dueDate: new Date(2025, 1, 21), amount: 100, paid: false },
  { id: 12, name: "Expense", dueDate: new Date(2025, 1, 24), amount: 100, paid: false },
  { id: 13, name: "Expense", dueDate: new Date(2025, 1, 27), amount: 100, paid: false },
  { id: 14, name: "Expense", dueDate: new Date(2025, 2, 1), amount: 100, paid: false },
  { id: 15, name: "Expense", dueDate: new Date(2025, 2, 4), amount: 100, paid: false },
  { id: 16, name: "Expense", dueDate: new Date(2025, 2, 7), amount: 100, paid: false },
  { id: 17, name: "Expense", dueDate: new Date(2025, 2, 10), amount: 100, paid: false },
  { id: 18, name: "Expense", dueDate: new Date(2025, 2, 13), amount: 100, paid: false },
  { id: 19, name: "Expense", dueDate: new Date(2025, 2, 16), amount: 100, paid: false },
  { id: 20, name: "Expense", dueDate: new Date(2025, 2, 20), amount: 100, paid: false },
]

const allExpenses = {
  0: expensesData,
  1: diegoExpenses,
  2: caExpenses,
}

export default function Home() {
  const [activeMenuIndex, setActiveMenuIndex] = React.useState(0)
  const [expenses, setExpenses] = React.useState(allExpenses[activeMenuIndex as keyof typeof allExpenses])

  React.useEffect(() => {
    // Request notification permission when the app loads
    requestNotificationPermission()

    // Check for expenses due in 2 days
    const checkDueDates = () => {
      expenses.forEach((expense) => {
        if (!expense.paid) {
          const daysUntilDue = Math.ceil((expense.dueDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
          if (daysUntilDue === 2) {
            sendNotification(expense)
          }
        }
      })
    }

    // Check immediately and then every hour
    checkDueDates()
    const interval = setInterval(checkDueDates, 1000 * 60 * 60)

    return () => clearInterval(interval)
  }, [expenses])

  React.useEffect(() => {
    setExpenses(allExpenses[activeMenuIndex as keyof typeof allExpenses])
  }, [activeMenuIndex])

  const handlePaidChange = (id: number, paid: boolean) => {
    setExpenses((prev) => prev.map((expense) => (expense.id === id ? { ...expense, paid } : expense)))
  }

  return (
    <div className="min-h-full">
      <header className="fixed top-0 left-0 right-0 bg-[#073763] text-white h-24 pt-[env(safe-area-inset-top)] z-20">
        <div className="h-full flex items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/C&A-YCnu6v9e9yS58ZNTDdI5m9Fjp7BOFd.svg"
              alt="C&A Logo"
              width={64}
              height={64}
              className="w-16 h-16"
              priority
            />
            <div>
              <h1 className="font-bold text-lg">EXPENSES</h1>
              <p className="text-gray-300 text-sm">{format(new Date(), "MMMM yyyy", { locale: enUS })}</p>
            </div>
          </div>
          <div className="text-lg font-bold">| {navItems[activeMenuIndex].name}</div>
        </div>
      </header>

      <NavigationMenu activeIndex={activeMenuIndex} onActiveChange={setActiveMenuIndex} />

      <main className="mt-[calc(96px+56px+env(safe-area-inset-top))] px-4 py-6 pb-28">
        {expenses.map((expense) => (
          <ExpenseCard
            key={expense.id}
            name={expense.name}
            dueDate={expense.dueDate}
            amount={expense.amount}
            paid={expense.paid}
            onPaidChange={(paid) => handlePaidChange(expense.id, paid)}
          />
        ))}
      </main>

      <CalendarButton />
    </div>
  )
}

