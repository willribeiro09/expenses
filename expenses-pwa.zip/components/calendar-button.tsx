"use client"

import * as React from "react"
import { CalendarIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Calendar } from "@/components/ui/calendar"
import { enUS } from "date-fns/locale"

export function CalendarButton() {
  const [open, setOpen] = React.useState(false)
  const today = new Date()

  return (
    <>
      <Button
        size="icon"
        className="h-14 w-14 rounded-full fixed bottom-8 right-4 bg-[#5abb37] hover:bg-[#4CAF50] shadow-lg z-10 touch-manipulation"
        onClick={() => setOpen(true)}
      >
        <CalendarIcon className="h-6 w-6" />
        <span className="sr-only">Open calendar</span>
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100vw-2rem)] sm:max-w-[400px] p-0">
          <DialogHeader className="p-4 pb-0">
            <DialogTitle>Calendar</DialogTitle>
          </DialogHeader>
          <div className="p-4">
            <Calendar mode="single" defaultMonth={today} selected={today} locale={enUS} disabled className="mx-auto" />
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}

