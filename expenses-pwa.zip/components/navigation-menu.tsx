"use client"

import * as React from "react"
import { User, Store } from "lucide-react"
import { cn } from "@/lib/utils"

export const navItems = [
  { name: "Carlos", icon: User },
  { name: "Diego", icon: User },
  { name: "C&A", icon: Store },
]

interface NavigationMenuProps {
  activeIndex: number
  onActiveChange: (index: number) => void
}

export function NavigationMenu({ activeIndex, onActiveChange }: NavigationMenuProps) {
  return (
    <nav className="bg-[#5abb37] fixed top-[96px] left-0 right-0 h-14 px-2 flex items-center justify-center shadow-md z-10">
      <div className="flex items-center justify-center gap-4 h-full">
        {navItems.map((item, index) => {
          const Icon = item.icon
          return (
            <button
              key={item.name}
              onClick={() => onActiveChange(index)}
              className={cn(
                "flex items-center gap-2 px-3 h-full text-white/90 hover:text-white transition-colors relative touch-manipulation",
                activeIndex === index && "text-white",
              )}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium text-sm">{item.name}</span>
              {activeIndex === index && (
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-white rounded-t-full" />
              )}
            </button>
          )
        })}
      </div>
    </nav>
  )
}

