"use client"

import * as React from "react"
import { CalendarIcon, X } from "lucide-react"
import { DayPicker } from "react-day-picker"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

export function CalendarModal() {
  const [open, setOpen] = React.useState(false)
  const [selected, setSelected] = React.useState<Date>()

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          size="icon"
          className="h-14 w-14 rounded-full fixed bottom-24 right-4 bg-[#5abb37] hover:bg-[#4CAF50] shadow-lg"
        >
          <CalendarIcon className="h-6 w-6" />
          <span className="sr-only">Open calendar</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle>Select date</DialogTitle>
          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setOpen(false)}>
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </Button>
        </DialogHeader>
        <DayPicker mode="single" selected={selected} onSelect={setSelected} className="mx-auto" />
      </DialogContent>
    </Dialog>
  )
}

