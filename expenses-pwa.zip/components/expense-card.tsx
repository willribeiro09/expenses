import * as React from "react"
import { cn } from "@/lib/utils"
import { AnimatedCheckbox } from "./ui/custom-checkbox"
import { format } from "date-fns"
import { enUS } from "date-fns/locale"

interface ExpenseCardProps {
  name: string
  dueDate: Date
  amount: number
  paid: boolean
  onPaidChange: (paid: boolean) => void
}

export function ExpenseCard({ name, dueDate, amount, paid, onPaidChange }: ExpenseCardProps) {
  const daysUntilDue = Math.ceil((dueDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))

  const getStatusStyles = () => {
    if (paid) return "bg-[#e8f5e9] border-l-[#5abb37]"
    if (daysUntilDue <= 3 && daysUntilDue > 0) return "bg-[#fff3cd] border-l-yellow-400"
    if (daysUntilDue < 0) return "bg-[#f8d7da] border-l-red-500"
    return "bg-white border-l-transparent"
  }

  return (
    <div
      className={cn(
        "flex items-center gap-3 p-3 border-l-4 rounded-lg shadow-sm mb-3 transition-colors touch-manipulation",
        getStatusStyles(),
      )}
    >
      <AnimatedCheckbox
        checked={paid}
        onChange={(e) => onPaidChange(e.target.checked)}
        aria-label={`Mark ${name} as paid`}
        className="flex-shrink-0"
      />
      <div className="flex-1 min-w-0">
        <h3 className="font-bold text-[#2d3436] truncate text-sm">{name}</h3>
        <p className="text-gray-600 text-xs">Due on {format(dueDate, "MMMM d", { locale: enUS })}</p>
      </div>
      <div className="text-[#2e7d32] font-medium whitespace-nowrap text-sm">
        {amount.toLocaleString("en-US", { style: "currency", currency: "USD" })}
      </div>
    </div>
  )
}

